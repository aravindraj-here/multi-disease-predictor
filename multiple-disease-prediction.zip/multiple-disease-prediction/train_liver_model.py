import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, classification_report
import joblib
import os

# Load liver dataset
df = pd.read_csv("data/indian_liver_patient.csv")

# Encode 'Gender' column (Male = 1, Female = 0)
df['Gender'] = LabelEncoder().fit_transform(df['Gender'])

# Replace missing Albumin and Globulin Ratio values
df['Albumin_and_Globulin_Ratio'].fillna(df['Albumin_and_Globulin_Ratio'].mean(), inplace=True)

# Target: 1 = disease, 2 = healthy → Let's make it binary: 1 = liver disease, 0 = healthy
df['Dataset'] = df['Dataset'].apply(lambda x: 1 if x == 1 else 0)

# Features and Target
X = df.drop('Dataset', axis=1)
y = df['Dataset']

# Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Eval
print("Liver Disease Prediction Accuracy:", accuracy_score(y_test, y_pred))
print("\nReport:\n", classification_report(y_test, y_pred))

# Save model
os.makedirs("models", exist_ok=True)
joblib.dump(model, "models/liver_model.pkl")
